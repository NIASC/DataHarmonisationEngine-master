package org.company_name;

import org.company_name.factories.ValidatorFactory;
import org.company_name.validators.DataValidator;

public class Main {
    public static void main(String[] args) {
        Cli cli = new Cli(args);
        cli.parse();
    }
}
