package org.company_name;


import java.util.HashMap;
import java.util.Map;

public class ColumnHeaderMapper {
    static Map<String, String> columnNames;

    public Map<String, Integer> getColumnMap() {
        return columnMap;
    }

    Map<String, Integer> columnMap;
    //labcode;pnr;smearyear;referralnr;refsite;scrtype;smeardate;regdate;topo;snomed;sampletype;residc;residk;responsedate

    static {
        columnNames = new HashMap<>();
        columnNames.put("pnr", "pnr");
        columnNames.put("smearyear","sampleYear");
        columnNames.put("referralnr","referralNumber");
        columnNames.put("refsite", "referralSite");
        //scrType needs some explanation
        columnNames.put("scrtype", "scrType");
        columnNames.put("smeardate", "sampleDate");
        columnNames.put("regdate", "regDate");
        columnNames.put("topo", "topo");
        columnNames.put("snomed", "snomed");
        columnNames.put("sampletype", "sampleType");
        columnNames.put("residc", "countyCode");
        columnNames.put("residk", "residk");
        columnNames.put("responseDate", "residk");
    }

    public void mapHeaderToIndex(String[] headers) {
        columnMap = new HashMap<>();
        for (int i = 0; i < headers.length ; i++) {
            columnMap.put(columnNames.get(headers[i]),i);
        }
    }

}
