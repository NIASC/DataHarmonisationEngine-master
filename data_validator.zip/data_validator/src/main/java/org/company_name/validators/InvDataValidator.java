package org.company_name.validators;

/**
 * Created by iliaaptsiauri on 09/05/16.
 */
public class InvDataValidator  {
//    public static final DataValidator INSTANCE = new InvDataValidator();
//    private InvDataValidator(){};
//
//    @Override
//    public String validate(String data) {
//        return "InvDataValidator was executed\n";
//    }
}