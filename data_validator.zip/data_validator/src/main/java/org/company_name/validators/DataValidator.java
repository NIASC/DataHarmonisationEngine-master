package org.company_name.validators;

import java.util.Map;

/**
 * Created by iliaaptsiauri on 04/05/16.
 */
public interface DataValidator {
     boolean validate(Map<String, Integer> columns, String[] data);
}
