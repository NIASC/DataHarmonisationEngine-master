package org.company_name.validators;

/**
 * Created by iliaaptsiauri on 04/05/16.
 */
public class PadDataValidator  {
//    public static final DataValidator INSTANCE = new PadDataValidator();
//    private PadDataValidator(){};
//
//    public String validate(String data) {
//        return "PadDataValidator was executed\n";
//    }
}
