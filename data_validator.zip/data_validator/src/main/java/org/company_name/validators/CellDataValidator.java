package org.company_name.validators;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.Map;

/**
 * Created by iliaaptsiauri on 04/05/16.
 */
public class CellDataValidator implements DataValidator {
    public static final DataValidator INSTANCE = new CellDataValidator();

    private CellDataValidator() { }

    public boolean validate(Map<String, Integer> columns, String[] data) {
        return validateSwedishId(data[columns.get("pnr")]) &&
                validateSampleYear(data[columns.get("sampleYear")]) &&
                validateRegistrationDate(data[columns.get("regDate")]) &&
                validateCountyCode(data[columns.get("countyCode")]) &&
                validateSampleDate(data[columns.get("sampleDate")]);
    }

    private final int COUNTY_NUMBER = 25;

    private boolean validateSwedishId(String idCode) {
        return true;
    }

    private boolean validateSampleYear(String sampleYear) {
        return sampleYear.trim().matches("^\\d{4}");
    }

    private boolean validateSampleDate(String sampleDate) {
        return validaFullDate(sampleDate.trim());
    }

    private boolean validateRegistrationDate(String regDate) {
        return validaFullDate(regDate.trim());
    }

    private boolean validateDiagnoseDate(String regDate) {
        return validaFullDate(regDate.trim());
    }

    private boolean validateCountyCode(String countyCode) {
        return Integer.parseInt(countyCode) <= COUNTY_NUMBER;
    }

    private boolean validaFullDate(String fullDate) {
        DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                .appendPattern("yyyyMMdd")
                .parseStrict()
                .toFormatter();
        try {
            LocalDate.parse(fullDate, formatter);
            return true;
        } catch (DateTimeParseException e) {
            //Todo Logger should be implemented
            System.out.println("Date parsing error");
            return false;
        }
    }
}
