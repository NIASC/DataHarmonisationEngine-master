package org.company_name;

import org.company_name.factories.ValidatorFactory;
import org.company_name.validators.DataValidator;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by iliaaptsiauri on 09/05/16.
 */
public class FileProcessor {
    public static void process(String inputPath, String outputPath, String type){
        DataValidator validator = ValidatorFactory.getInstance(type);
        ColumnHeaderMapper columnHeaderMapper = new ColumnHeaderMapper();

        try(BufferedReader reader = Files.newBufferedReader(Paths.get(inputPath));
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(outputPath))) {

            String line;
            int lineCount = 0;

            while ((line = reader.readLine()) != null) {
                System.out.println("Raw CSV data: " + line);
                if(lineCount == 0) {
                    columnHeaderMapper.mapHeaderToIndex(line.split(";"));
                }else {
                    if(validator.validate(columnHeaderMapper.getColumnMap(), line.split(";"))){
                        writer.write(line + "\n");
                    }
                }
                lineCount++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
